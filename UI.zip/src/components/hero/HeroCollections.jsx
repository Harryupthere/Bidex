import React from 'react';

function HeroCollections() {
  return (
    <div>
      <div>
        <div className="hero__collections">
          <div className="container">
            <h1>Artwork collections</h1>
          </div>
        </div>
      </div>
    </div>
  );
}

export default HeroCollections;
