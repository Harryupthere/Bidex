import React from "react";

function HeroTerms() {
  return (
    <div>
      <div className="hero_privacy mb-5">
        <div className="container">
          <div className="d-flex justify-content-center align-items-center space-x-10">
            <h1 className="text-left">Bidex NFT Terms and Conditions</h1>
          </div>
        </div>
      </div>
    </div>
  );
}

export default HeroTerms;
