import React from 'react';

const HeroRanking = () => {
  return (
    <div>
      <div className="hero_ranking bg_white">
        <div className="container">
          <h1 className="text-center">Ranking NFT</h1>
        </div>
      </div>
    </div>
  );
};

export default HeroRanking;
