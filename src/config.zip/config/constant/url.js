export const IPFS_URL = "https://cf-ipfs";
// export const GRAPHQL_API = "http://103.199.215.95:3002";
export const GRAPHQL_API = "http://192.168.0.101:5000";
export const TRANSAK_API = "36da2bff-64b1-4265-a117-85e2644ed0ad";
